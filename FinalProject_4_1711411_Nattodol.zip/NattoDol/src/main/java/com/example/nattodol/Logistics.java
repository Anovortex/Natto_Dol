package com.example.nattodol;

public class Logistics {
}
