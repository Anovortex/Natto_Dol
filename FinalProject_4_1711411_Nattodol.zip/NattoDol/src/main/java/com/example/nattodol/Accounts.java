package com.example.nattodol;

public class Accounts {
}
